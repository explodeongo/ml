# -*- coding: utf-8 -*-
"""
Created on Mon Feb  5 22:08:55 2024

@author: TANMAY
"""

import pandas as pd
from sklearn.naive_bayes import CategoricalNB
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix

doc_num=pd.read_csv('NPHA-doctor-visits.csv',sep=',')
doc_num.drop(['Age'],axis=1,inplace=True)
doc_num.drop(['Gender'],axis=1,inplace=True)

features=['Phyiscal Health','Mental Health','Dental Health','Employment','Stress Keeps Patient from Sleeping','Medication Keeps Patient from Sleeping','Pain Keeps Patient from Sleeping','Bathroom Needs Keeps Patient from Sleeping','Uknown Keeps Patient from Sleeping','Trouble Sleeping','Prescription Sleep Medication','Race']
target="Number of Doctors Visited"
doc_num.replace(-1,10,inplace=True)
#doc_num.replace(-2,11,inplace=True)

x=doc_num[features]
y=doc_num[target]

X_train, X_test, y_train, y_test = train_test_split(x, y, test_size=0.2 ,stratify=y)

clf = CategoricalNB()

clf.fit(X_train,y_train)
y_pred=clf.predict(X_test)
accuracy_score(y_test, y_pred)
confusion_matrix(y_test, y_pred)

df=pd.DataFrame(doc_num)
unique_values = {col: df[col].unique() for col in df.columns}
print(unique_values)









import pandas as pd
from sklearn.naive_bayes import CategoricalNB
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix

doc_num=pd.read_csv('NPHA-doctor-visits.csv',sep=',')
doc_num.drop(['Age'],axis=1,inplace=True)
doc_num.drop(['Gender'],axis=1,inplace=True)
print("New shape of the dataframe before dropping rows:", doc_num.shape)

rows_to_drop = doc_num[(doc_num < 0).any(axis=1) | (doc_num > 5).any(axis=1)]

print("Rows to be dropped:")
print(rows_to_drop)

doc_num.drop(rows_to_drop.index, inplace=True)

print("New shape of the dataframe after dropping rows:", doc_num.shape)


features=['Phyiscal Health','Mental Health','Dental Health','Employment','Stress Keeps Patient from Sleeping','Medication Keeps Patient from Sleeping','Pain Keeps Patient from Sleeping','Bathroom Needs Keeps Patient from Sleeping','Uknown Keeps Patient from Sleeping','Trouble Sleeping','Prescription Sleep Medication','Race']
target="Number of Doctors Visited"
#doc_num.replace(-1,10,inplace=True)
#doc_num.replace(-2,11,inplace=True)

x=doc_num[features]
y=doc_num[target]
acc=[]
acc_c=0
c= None
for i in range(10):
    X_train, X_test, y_train, y_test = train_test_split(x, y, test_size=0.3 ,stratify=y)

    clf = CategoricalNB()

    clf.fit(X_train,y_train)
    y_pred=clf.predict(X_test)
    acc.append(accuracy_score(y_test, y_pred))
    acc_c=acc_c+accuracy_score(y_test, y_pred)
    c=confusion_matrix(y_test, y_pred)
    print(c)
    c=None
print('Average accuracy of 10 splits : ',acc_c/10)
print('accuracies were : ',acc)



# Check column names
print("Column Names:", doc_num.columns)

# Check unique values for each feature
for feature in features:
    print("Unique values for", feature, ":", doc_num[feature].unique())

# Check for missing values
print("Missing Values:", doc_num.isnull().sum())

# Check the number of unique values for each feature
for feature in features:
    print("Number of unique values for", feature, ":", len(doc_num[feature].unique()))

print("Unique values for target variable 'Number of Doctors Visited':", doc_num['Number of Doctors Visited'].unique())


print("Shape of X_train:", X_train.shape)
print("Shape of X_test:", X_test.shape)
print("Shape of y_train:", y_train.shape)
print("Shape of y_test:", y_test.shape)




