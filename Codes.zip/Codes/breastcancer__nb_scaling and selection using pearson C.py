# -*- coding: utf-8 -*-
"""
Created on Wed Oct 13 22:36:49 2021

@author: BALJEET KAUR
"""

from sklearn import datasets
from sklearn.preprocessing import MinMaxScaler


from sklearn.naive_bayes import GaussianNB
from sklearn import metrics
from sklearn.model_selection import train_test_split
breast_cancer = datasets.load_breast_cancer()

X = breast_cancer.data
y = breast_cancer.target


scaler = MinMaxScaler((0,1))
X=scaler.fit_transform(X)


x_train, x_test, y_train, y_test = train_test_split(X, y, test_size = 0.2, random_state = 0)
gnb = GaussianNB()



#Feaure Scaling




gnb.fit(x_train, y_train)

y_test_hat=gnb.predict(x_test) 

test_accuracy=metrics.accuracy_score(y_test,y_test_hat)*100

print("Accuracy for our testing dataset without tuning is : {:.2f}%".format(test_accuracy) )

#FEATURE Scaling and Feature RELEVANCE

import numpy as np
import pandas as pd


scaler = MinMaxScaler((0,1))
X=scaler.fit_transform(X)

df=pd.DataFrame(X)
#df=pd.DataFrame(X,columns=breast_cancer.feature_names)
df['class']=y
corr_data=df.corr()
import seaborn as sns
sns.heatmap(corr_data)
sel_data=(abs(corr_data['class'])>0.60) & (abs(corr_data['class'])<1.0)  
X_small=X[:,sel_data[:30]];
breast_cancer.feature_names[sel_data[:30]]

x_train, x_test, y_train, y_test = train_test_split(X_small, y, test_size = 0.2, random_state = 0)

gnb.fit(x_train, y_train)

y_test_hat=gnb.predict(x_test) 

test_accuracy=metrics.accuracy_score(y_test,y_test_hat)*100

print("Accuracy for our testing dataset with tuning is : {:.2f}%".format(test_accuracy) )
