"""
Created on Wed Jan 31 21:42:17 2024

@author: kaush
"""

from sklearn.datasets import make_blobs
from scipy.stats import norm
from numpy import mean, std

# Fit a probability distribution to a univariate data sample
def fit_distribution(data):
    # Estimate parameters
    mu = mean(data)
    sigma = std(data)
    # Fit distribution
    dist = norm(mu, sigma)
    return dist

# Calculate the independent conditional probability
def probability(X, prior, dist1, dist2):
    return prior * dist1.pdf(X[0]) * dist2.pdf(X[1])

# Generate 2D classification dataset
X, y = make_blobs(n_samples=100, centers=3, n_features=2, random_state=1, cluster_std=1)

import matplotlib.pyplot as plt

plt.scatter(X[:, 0], X[:, 1], c=y)

# Sort data into classes
Xy0 = X[y == 0]
Xy1 = X[y == 1]
Xy2 = X[y == 2]

# Calculate priors
priory0 = len(Xy0) / len(X)
priory1 = len(Xy1) / len(X)
priory2 = len(Xy2) / len(X)

# Create PDFs for y==0
distX1y0 = fit_distribution(Xy0[:, 0])
distX2y0 = fit_distribution(Xy0[:, 1])

# Create PDFs for y==1
distX1y1 = fit_distribution(Xy1[:, 0])
distX2y1 = fit_distribution(Xy1[:, 1])

# Create PDFs for y==2
distX1y2 = fit_distribution(Xy2[:, 0])
distX2y2 = fit_distribution(Xy2[:, 1])

# Classify all examples and calculate accuracy
correct_predictions = 0
predicted_arr=[]

for i in range(len(X)):
    Xsample, ysample = X[i], y[i]
    py0 = probability(Xsample, priory0, distX1y0, distX2y0)
    py1 = probability(Xsample, priory1, distX1y1, distX2y1)
    py2 = probability(Xsample, priory2, distX1y2, distX2y2)
    
    predicted_class = max([(py0, 0), (py1, 1), (py2, 2)], key=lambda x: x[0])[1] #extract the class
    
    predicted_arr.append(predicted_class)
    if predicted_class == ysample:
        correct_predictions += 1

print(predicted_arr)
accuracy = correct_predictions / len(X) * 100
print('Accuracy: %.2f%%' % accuracy)


