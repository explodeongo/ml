# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

import numpy as np
import matplotlib.pyplot as plt

# generate random data-set
np.random.seed(0)
input1=np.array([[0,0,1],[0,1,1],[1,0,1],[1,1,1]]).T;

weights = np.random.rand( 3)
label=np.array([0,0,0,1])
predicted=np.array([0,0,0,0]);
eeta=0.1




def perceptron_train(count):
    
    for i in range(count):    
        weightedsumarr=weights.dot(input1).T
        
        
        for i in range(4):
            if weightedsumarr[i] >=0:
                predicted[i]=1
            else:
                predicted[i]=0
                
                
        
        
        for i in range(4):
            if label[i] != predicted[i]:
                x=input1[:,i]
                delw0=eeta*(label[i]-predicted[i])*x[0]
                delw1=eeta*(label[i]-predicted[i])*x[1]
                delw2=eeta*(label[i]-predicted[i])*x[2]
                weights[0]=weights[0]+delw0;
                weights[1]=weights[1]+delw1;
                weights[2]=weights[2]+delw2;
                
        print(predicted)
        print(label)        
        print(np.mean(predicted==label)*100)        

perceptron_train(10)