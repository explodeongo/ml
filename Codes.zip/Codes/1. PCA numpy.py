#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Feb 10 12:27:55 2024

@author: baljeetkaur
"""


'''
The example below defines a small 3×2 matrix, 
centers the data in the matrix, 
calculates the covariance matrix of the centered data,
and then the eigendecomposition of the covariance matrix. 
The eigenvectors and eigenvalues are taken as the principal components
and the scale and 
used to project the original data.
'''

from numpy import array
from numpy import mean
from numpy import cov
from numpy.linalg import eig

# define a matrix
A = array([[1, 21], [3, 14], [5, 6]])
print(A)
# calculate the mean of each column


#mean(A, axis=0) or 
     
M = mean(A.T, axis=1)
print(M)
# center columns by subtracting column means
A1 = A - M
print(A1)
# calculate covariance matrix of centered matrix
C = cov(A1.T)
print(C)
# eigendecomposition of covariance matrix
values, vectors = eig(C)
print(vectors)
print(values)
# project data
P = vectors.T.dot(A1.T)
print(P.T)
