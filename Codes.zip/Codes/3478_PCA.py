# -*- coding: utf-8 -*-
"""
Created on Sun Feb 18 01:35:54 2024

@author: kaush
"""

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import accuracy_score
from sklearn.preprocessing import MinMaxScaler, LabelEncoder, StandardScaler


df = pd.read_csv('apple_quality.csv')

label_encoder = LabelEncoder()
df['Quality'] = label_encoder.fit_transform(df['Quality'])
df.dropna(inplace=True)

df.drop('A_id', axis=1, inplace=True)

# Define features and target
features = ['Size', 'Weight', 'Sweetness', 'Crunchiness', 'Juiciness', 'Ripeness', 'Acidity']
target = "Quality"

scaler = StandardScaler()
df_scaled = df.copy()
df_scaled[features] = scaler.fit_transform(df_scaled[features])


X = df_scaled[features]
y = df_scaled[target]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3,stratify=y, random_state=0)

gnb = GaussianNB()
gnb.fit(X_train, y_train)

y_test_hat = gnb.predict(X_test)
test_accuracy = accuracy_score(y_test, y_test_hat) * 100

print("Accuracy for the testing dataset without tuning: {:.2f}%".format(test_accuracy))


from sklearn.decomposition import PCA

results = []

for n_features in range(1, len(features) + 1):
    X = df_scaled[features]
    y = df_scaled[target]
    
    pca = PCA(n_components=n_features)
    X_pca = pca.fit_transform(X)
    X_train, X_test, y_train, y_test = train_test_split(X_pca, y, test_size=0.3,stratify=y, random_state=0)
    gnb = GaussianNB()
    gnb.fit(X_train, y_train)
    y_test_hat = gnb.predict(X_test)
    test_accuracy = accuracy_score(y_test, y_test_hat) * 100
    
    results.append({'No. of Features': n_features,
                    'Accuracy': test_accuracy,
                    'Explained Variance Ratio': sum(pca.explained_variance_ratio_)})

results_df = pd.DataFrame(results)
results_df.to_excel('3478_pca_results.xlsx', index=False)
print(results_df)