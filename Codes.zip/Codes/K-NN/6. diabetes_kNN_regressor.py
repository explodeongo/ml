# -*- coding: utf-8 -*-
"""
Created on Mon Jul  6 18:04:26 2020

@author: BALJEET KAUR
"""

from sklearn import datasets


diab= datasets.load_diabetes()
x=diab.data
diab.feature_names
y=diab.target
diab.data.shape

from sklearn.neighbors import KNeighborsRegressor
from sklearn import metrics

knn=KNeighborsRegressor(n_neighbors=2)
knn=KNeighborsRegressor(n_neighbors=5,weights='distance')

#knn=KNeighborsClassifier(n_neighbors=5)   #5 2 1
knn.fit(x,y)
y_predict=knn.predict(x)

score=metrics.mean_squared_error(y, y_predict)
print(score)





