# -*- coding: utf-8 -*-
"""
Created on Tue Feb 27 09:57:23 2024

@author: kaush
"""

from sklearn.datasets import fetch_california_housing
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsRegressor
from sklearn.metrics import mean_squared_error


housing = fetch_california_housing()


X=housing.data
housing.feature_names
y=housing.target
print(housing.data.shape, housing.target.shape)

import numpy as np

null_values = np.isnan(X).sum(axis=0)

for i, feature in enumerate(housing.feature_names):
    print(f"Null values in {feature}: {null_values[i]}")

from sklearn.datasets import fetch_california_housing


# Scale the features
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

knn_regressor = KNeighborsRegressor()

knn_regressor.fit(X_train, y_train)


y_pred = knn_regressor.predict(X_test)

mse = mean_squared_error(y_test, y_pred)

print("Mean Squared Error:", mse)
