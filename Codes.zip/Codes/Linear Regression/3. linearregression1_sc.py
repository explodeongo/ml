# -*- coding: utf-8 -*-
"""
Created on Sat Oct  5 18:34:35 2019

@author: BALJEET
"""

# imports
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score


data = pd.read_csv('ex1data1.txt', header = None) #read from dataset
x = data.iloc[:,0]
x=x.values.reshape(x.size,1) # read first column
y = data.iloc[:,1].values.reshape(-1,1) # read second column


# Model initialization
regression_model = LinearRegression()
# Fit the data(train the model)
regression_model.fit(x, y)

# printing values
print('Slope:' ,regression_model.coef_)
print('Intercept:', regression_model.intercept_)


# Predict
y_predicted = regression_model.predict(x)


# data points
plt.scatter(x, y)
plt.xlabel('x')
plt.ylabel('y')

# predicted values
plt.plot(x, y_predicted, color='r')
plt.show()

# model evaluation
mse = mean_squared_error(y, y_predicted)
r2 = r2_score(y, y_predicted)
print('mean squared error: ', mse)
print('R2 score: ', r2)



from sklearn.model_selection import train_test_split

X_train, X_test, y_train, y_test = train_test_split(x, y, test_size = 0.2)


#linear regression
model = LinearRegression()   #LOW TRAIN AND TESY
model.fit(X_train, y_train)
y_train_pred = model.predict(X_train)

mse = mean_squared_error(y_train, y_train_pred)
r2 = r2_score(y_train, y_train_pred)

print(' mean squared error train: ', mse)
print('R2 score train: ', r2)
print('Slope:' ,model.coef_)
print('Intercept:', model.intercept_)

plt.scatter(X_train, y_train, s=10)
plt.scatter(X_train, y_train_pred, s=10,color='r')


y_test_pred = model.predict(X_test)

mse = (mean_squared_error(y_test, y_test_pred))
r2 = r2_score(y_test, y_test_pred)

print('mean squared error test: ', mse)
print('R2 score  test: ', r2)

plt.scatter(X_test, y_test, s=10,color='g')
plt.scatter(X_test, y_test_pred, s=10,color='r')

