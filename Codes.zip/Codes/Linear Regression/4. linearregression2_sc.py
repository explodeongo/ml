# -*- coding: utf-8 -*-
"""
Created on Sat Oct  5 18:34:35 2019

@author: BALJEET
"""

# imports
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.preprocessing import StandardScaler

data = pd.read_csv('ex1data2.txt', header = None) #read from dataset
x = data.iloc[:,0:2].values

 # read first two column
y = data.iloc[:,2].values.reshape(-1,1) # read target column


# Model initialization
regression_model = LinearRegression()
# Fit the data(train the model)
regression_model.fit(x, y)
# Predict
y_predicted = regression_model.predict(x)



# model evaluation
mse = mean_squared_error(y, y_predicted)
r2 = r2_score(y, y_predicted)
print('mean squared error: ', mse)
print('R2 score: ', r2)

# printing values
print('Slope:' ,regression_model.coef_)
print('Intercept:', regression_model.intercept_)

std=StandardScaler()
x_std=std.fit_transform(x)
regression_model.fit(x_std, y)
# Predict
y_predicted = regression_model.predict(x_std)



# model evaluation
mse = mean_squared_error(y, y_predicted)
r2 = r2_score(y, y_predicted)
print('mean squared error: ', mse)
print('R2 score: ', r2)


from sklearn.model_selection import train_test_split

X_train, X_test, y_train, y_test = train_test_split(x, y, test_size = 0.2)


#linear regression
model = LinearRegression()   #LOW TRAIN AND TESY
model.fit(X_train, y_train)
y_train_pred = model.predict(X_train)

rmse = mean_squared_error(y_train, y_train_pred)
r2 = r2_score(y_train, y_train_pred)

print('mean squared error train: ', rmse)
print('R2 score train: ', r2)

y_test_pred = model.predict(X_test)

rmse = (mean_squared_error(y_test, y_test_pred))
r2 = r2_score(y_test, y_test_pred)

print('mean squared error test: ', rmse)
print('R2 score  test: ', r2)


