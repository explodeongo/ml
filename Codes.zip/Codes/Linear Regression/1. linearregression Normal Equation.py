# -*- coding: utf-8 -*-
"""
Created on Wed Oct  2 22:38:04 2019

@author: BALJEET
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


data = pd.read_csv('ex1data1.txt', header = None) #read from dataset
X = data.iloc[:,0] # read first column
y = data.iloc[:,1] # read second column
m = len(y) # number of training example
data.head() # view first few rows of the data


plt.scatter(X, y)
plt.xlabel('Population of City in 10,000s')
plt.ylabel('Profit in $10,000s')
plt.show()
X=np.array(X).reshape(X.shape[0],1)
y=np.array(y).reshape(y.shape[0],1)



ones = np.ones((m,1))
X = np.hstack((ones, X)) # adding the intercept term







#normal equation method



def theta_calc(x,y):
    theta_1=np.linalg.inv(np.dot(x.T,x))
    theta_2=np.dot(theta_1,x.T)
    theta=np.dot(theta_2,y)
    return theta


theta_val=theta_calc(X,y)
print(theta_val)  

plt.scatter(X[:,1], y)
plt.plot(X[:,1], np.dot(X, theta_val),color='r')
plt.show()

np.dot(X[7, :],theta_val)  #predict 

