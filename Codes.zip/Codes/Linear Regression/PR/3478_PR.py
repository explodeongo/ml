# -*- coding: utf-8 -*-
"""
Created on Tue Mar 12 09:56:41 2024

@author: kaush
"""

import numpy as np
from sklearn.datasets import fetch_california_housing
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score, mean_squared_error
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt

''' 
# Fetch the Olivetti Faces dataset
faces_data = fetch_california_housing()

# Extract features and target
X = faces_data.data
y = faces_data.target

# Check for null values
null_values = np.isnan(X).sum()
print("Null values in the dataset:", null_values)

'''

from ucimlrepo import fetch_ucirepo 
  
# fetch dataset 
auto_mpg = fetch_ucirepo(id=9) 
  
# data (as pandas dataframes) 
X = auto_mpg.data.features 
y = auto_mpg.data.targets 

null_values = np.isnan(X).sum()
print("Null values in the dataset:", null_values)

X_cleaned = X.dropna()
y_cleaned = y[X.index.isin(X_cleaned.index)]

# Check the new shape after dropping null values
print("Shape of X after dropping rows with null values:", X_cleaned.shape)
print("Shape of y after dropping corresponding rows with null values:", y_cleaned.shape)


