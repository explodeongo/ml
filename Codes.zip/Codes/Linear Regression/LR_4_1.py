# -*- coding: utf-8 -*-
"""
Created on Mon Mar 11 18:03:42 2024

@author: kripl
"""

import numpy as np
import pandas as pd 
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score, mean_squared_error
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
from sklearn.preprocessing import PolynomialFeatures

data = pd.read_csv('Real estate.csv')
data.columns
data.head
y = data['Y house price of unit area'] 
X = data.drop('Y house price of unit area', axis =1)

y = np.array(y)
X = np.array(X)
y.var()
y.std()
List_MSE = []
List_R2 = []
Train_error = []
Test_error = []
Complexity = [1,2,3,4,5,6,7,8,9,10]
#for all data
model = LinearRegression()
model.fit(X,y)
y_pred = model.predict(X)

MSE = mean_squared_error(y, y_pred)
print("Mean Square Root", MSE)


R2 = r2_score(y, y_pred)
print("R2 score", R2)


X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

# for train data
model = LinearRegression()
model.fit(X_train,y_train)
y_train_pred = model.predict(X_train)

MSE = mean_squared_error(y_train, y_train_pred)
print("Mean Square Root", MSE)
Train_error.append(MSE)

R2 = r2_score(y_train, y_train_pred)
print("R2 score", R2)


# for test data
model = LinearRegression()
model.fit(X_test,y_test)
y_test_pred = model.predict(X_test)

MSE = mean_squared_error(y_test, y_test_pred)
print("Mean Square Root", MSE)
Test_error.append(MSE)

R2 = r2_score(y_test, y_test_pred)
print("R2 score", R2)

# Polynomial Regression for degree 2 (Train data)
polynomialFeatures = PolynomialFeatures(degree=2)
X_poly = polynomialFeatures.fit_transform(X_train)

model = LinearRegression()
model.fit(X_poly,y_train)
y_poly_pred = model.predict(X_poly)

MSE = mean_squared_error(y_train, y_poly_pred)
print("Mean Square Root", MSE)
Train_error.append(MSE)

R2 = r2_score(y_train, y_poly_pred)
print("R2 score", R2)


# Polynomial Regression for degree 2 (test data)
polynomialFeatures = PolynomialFeatures(degree=2)
X_poly = polynomialFeatures.fit_transform(X_test)

model = LinearRegression()
model.fit(X_poly,y_test)
y_poly_pred = model.predict(X_poly)

MSE = mean_squared_error(y_test, y_poly_pred)
print("Mean Square Root", MSE)
Test_error.append(MSE)

R2 = r2_score(y_test, y_poly_pred)
print("R2 score", R2)

# Polynomial Regression for degree 3 (Train data)
polynomialFeatures = PolynomialFeatures(degree=3)
X_poly = polynomialFeatures.fit_transform(X_train)

model = LinearRegression()
model.fit(X_poly,y_train)
y_poly_pred = model.predict(X_poly)

MSE = mean_squared_error(y_train, y_poly_pred)
print("Mean Square Root", MSE)
Train_error.append(MSE)

R2 = r2_score(y_train, y_poly_pred)
print("R2 score", R2)


# Polynomial Regression for degree 3 (test data)
polynomialFeatures = PolynomialFeatures(degree=3)
X_poly = polynomialFeatures.fit_transform(X_test)

model = LinearRegression()
model.fit(X_poly,y_test)
y_poly_pred = model.predict(X_poly)

MSE = mean_squared_error(y_test, y_poly_pred)
print("Mean Square Root", MSE)
Test_error.append(MSE)

R2 = r2_score(y_test, y_poly_pred)
print("R2 score", R2)

# Polynomial Regression for degree 4 (Train data)
polynomialFeatures = PolynomialFeatures(degree=4)
X_poly = polynomialFeatures.fit_transform(X_train)

model = LinearRegression()
model.fit(X_poly,y_train)
y_poly_pred = model.predict(X_poly)

MSE = mean_squared_error(y_train, y_poly_pred)
print("Mean Square Root", MSE)
Train_error.append(MSE)

R2 = r2_score(y_train, y_poly_pred)
print("R2 score", R2)


# Polynomial Regression for degree 4 (test data)
polynomialFeatures = PolynomialFeatures(degree=4)
X_poly = polynomialFeatures.fit_transform(X_test)

model = LinearRegression()
model.fit(X_poly,y_test)
y_poly_pred = model.predict(X_poly)

MSE = mean_squared_error(y_test, y_poly_pred)
print("Mean Square Root", MSE)
Test_error.append(MSE)

R2 = r2_score(y_test, y_poly_pred)
print("R2 score", R2)

# Polynomial Regression for degree 5 (Train data)
polynomialFeatures = PolynomialFeatures(degree=5)
X_poly = polynomialFeatures.fit_transform(X_train)

model = LinearRegression()
model.fit(X_poly,y_train)
y_poly_pred = model.predict(X_poly)

MSE = mean_squared_error(y_train, y_poly_pred)
print("Mean Square Root", MSE)
Train_error.append(MSE)

R2 = r2_score(y_train, y_poly_pred)
print("R2 score", R2)


# Polynomial Regression for degree 5 (test data)
polynomialFeatures = PolynomialFeatures(degree=5)
X_poly = polynomialFeatures.fit_transform(X_test)

model = LinearRegression()
model.fit(X_poly,y_test)
y_poly_pred = model.predict(X_poly)

MSE = mean_squared_error(y_test, y_poly_pred)
print("Mean Square Root", MSE)
Test_error.append(MSE)

R2 = r2_score(y_test, y_poly_pred)
print("R2 score", R2)

plt.scatter(Complexity[:5],Train_error, color='r')
plt.plot(Complexity[:5],Train_error, color='r',label='Train Error')
plt.scatter(Complexity[:5],Test_error, color = 'm')
plt.plot(Complexity[:5],Test_error, color = 'm', label='Test Error')
plt.title("Train and Test Error")
plt.xlabel("Complexity")
plt.ylabel("Errors")
plt.legend()
plt.show()


# Polynomial Regression for degree 6 (Train data)
polynomialFeatures = PolynomialFeatures(degree=6)
X_poly = polynomialFeatures.fit_transform(X_train)

model = LinearRegression()
model.fit(X_poly,y_train)
y_poly_pred = model.predict(X_poly)

MSE = mean_squared_error(y_train, y_poly_pred)
print("Mean Square Root", MSE)
Train_error.append(MSE)

R2 = r2_score(y_train, y_poly_pred)
print("R2 score", R2)


# Polynomial Regression for degree 6 (test data)
polynomialFeatures = PolynomialFeatures(degree=6)
X_poly = polynomialFeatures.fit_transform(X_test)

model = LinearRegression()
model.fit(X_poly,y_test)
y_poly_pred = model.predict(X_poly)

MSE = mean_squared_error(y_test, y_poly_pred)
print("Mean Square Root", MSE)
Test_error.append(MSE)

R2 = r2_score(y_test, y_poly_pred)
print("R2 score", R2)

# Polynomial Regression for degree 7 (Train data)
polynomialFeatures = PolynomialFeatures(degree=7)
X_poly = polynomialFeatures.fit_transform(X_train)

model = LinearRegression()
model.fit(X_poly,y_train)
y_poly_pred = model.predict(X_poly)

MSE = mean_squared_error(y_train, y_poly_pred)
print("Mean Square Root", MSE)
Train_error.append(MSE)

R2 = r2_score(y_train, y_poly_pred)
print("R2 score", R2)


# Polynomial Regression for degree 7 (test data)
polynomialFeatures = PolynomialFeatures(degree=7)
X_poly = polynomialFeatures.fit_transform(X_test)

model = LinearRegression()
model.fit(X_poly,y_test)
y_poly_pred = model.predict(X_poly)

MSE = mean_squared_error(y_test, y_poly_pred)
print("Mean Square Root", MSE)
Test_error.append(MSE)

R2 = r2_score(y_test, y_poly_pred)
print("R2 score", R2)

# Polynomial Regression for degree 8 (Train data)
polynomialFeatures = PolynomialFeatures(degree=8)
X_poly = polynomialFeatures.fit_transform(X_train)

model = LinearRegression()
model.fit(X_poly,y_train)
y_poly_pred = model.predict(X_poly)

MSE = mean_squared_error(y_train, y_poly_pred)
print("Mean Square Root", MSE)
Train_error.append(MSE)

R2 = r2_score(y_train, y_poly_pred)
print("R2 score", R2)


# Polynomial Regression for degree 8 (test data)
polynomialFeatures = PolynomialFeatures(degree=8)
X_poly = polynomialFeatures.fit_transform(X_test)

model = LinearRegression()
model.fit(X_poly,y_test)
y_poly_pred = model.predict(X_poly)

MSE = mean_squared_error(y_test, y_poly_pred)
print("Mean Square Root", MSE)
Test_error.append(MSE)

R2 = r2_score(y_test, y_poly_pred)
print("R2 score", R2)

# Polynomial Regression for degree 9 (Train data)
polynomialFeatures = PolynomialFeatures(degree=9)
X_poly = polynomialFeatures.fit_transform(X_train)

model = LinearRegression()
model.fit(X_poly,y_train)
y_poly_pred = model.predict(X_poly)

MSE = mean_squared_error(y_train, y_poly_pred)
print("Mean Square Root", MSE)
Train_error.append(MSE)

R2 = r2_score(y_train, y_poly_pred)
print("R2 score", R2)


# Polynomial Regression for degree 9 (test data)
polynomialFeatures = PolynomialFeatures(degree=9)
X_poly = polynomialFeatures.fit_transform(X_test)

model = LinearRegression()
model.fit(X_poly,y_test)
y_poly_pred = model.predict(X_poly)

MSE = mean_squared_error(y_test, y_poly_pred)
print("Mean Square Root", MSE)
Test_error.append(MSE)

R2 = r2_score(y_test, y_poly_pred)
print("R2 score", R2)

# Polynomial Regression for degree 10 (Train data)
polynomialFeatures = PolynomialFeatures(degree=10)
X_poly = polynomialFeatures.fit_transform(X_train)

model = LinearRegression()
model.fit(X_poly,y_train)
y_poly_pred = model.predict(X_poly)

MSE = mean_squared_error(y_train, y_poly_pred)
print("Mean Square Root", MSE)
Train_error.append(MSE)

R2 = r2_score(y_train, y_poly_pred)
print("R2 score", R2)


# Polynomial Regression for degree 10 (test data)
polynomialFeatures = PolynomialFeatures(degree=10)
X_poly = polynomialFeatures.fit_transform(X_test)

model = LinearRegression()
model.fit(X_poly,y_test)
y_poly_pred = model.predict(X_poly)

MSE = mean_squared_error(y_test, y_poly_pred)
print("Mean Square Root", MSE)
Test_error.append(MSE)

R2 = r2_score(y_test, y_poly_pred)
print("R2 score", R2)

Complexity = [1,2,3,4,5,6,7,8,9,10]

print(Train_error)
#print(np.log(Train_error))
print(Test_error)
#print(np.log(Test_error))
plt.grid()
plt.scatter(Complexity[:10],Train_error, color='r')
plt.plot(Complexity[:10],Train_error, color='r',label='Train Error')
plt.scatter(Complexity[:10],Test_error, color = 'm')
plt.plot(Complexity[:10],Test_error, color = 'm', label='Test Error')
plt.title("Train and Test Error")
plt.xlabel("Complexity")
plt.ylabel("Errors")
plt.legend()
plt.show()

plt.scatter(Complexity[:10],np.log(Train_error), color='r')
plt.plot(Complexity[:10],np.log(Train_error), color='r',label='Train Error')
plt.scatter(Complexity[:10],np.log(Test_error), color = 'm')
plt.plot(Complexity[:10],np.log(Test_error), color = 'm', label='Test Error')
plt.title("Train and Test Error")
plt.xlabel("Complexity")
plt.ylabel("Errors")
plt.legend()
plt.show()